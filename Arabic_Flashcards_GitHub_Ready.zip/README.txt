LET’S LEARN ARABIC — THE BASICS

Verified source: index.html (one self-contained file).

To update GitHub Pages:
1. Visit https://github.com/alientester/Arabic-flashcard-learning
2. Open index.html and choose Edit (pencil).
3. Replace its ENTIRE content with Arabic_Flashcards_FULL_CODE.txt, or upload the index.html from this ZIP.
4. Commit changes to the publishing branch.
5. Open https://alientester.github.io/Arabic-flashcard-learning/ in Safari and refresh.

Six decks: letters 28; letter forms 28; numbers 38; colors 12; fruits and vegetables 20; animals 16. Total: 142 cards. All 36 food and animal illustrations are embedded.

The code passed an automated Chromium browser smoke test covering each menu deck, card selection, first five, flipping, previous/next, grading, missed-review and return to menu. iPhone pronunciation and live GitHub deployment have not been independently verified. The pronunciation uses iPhone Arabic text-to-speech, not verified Qur'anic audio.
